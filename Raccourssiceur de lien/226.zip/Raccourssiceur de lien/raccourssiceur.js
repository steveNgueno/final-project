const input = document.getElementById('input');
const shorten_btn = document.querySelector('.btn');
const invalid = document.querySelector('.invalid');
const warning= document.querySelector('.div2 p');




function shortener(){
    if(!input.value == ""){
      
        warning.style.display = "none";

        let url = `https://api.shrtco.de/v2/shorten?url=${(input.value)}`;

        fetch(url)
        .then(response => response.json())
        .then(data => invalid.innerHTML = data.result.short_link);         
            invalid.style.display = 'block';

        if(invalid.innerHTML.length == 0){
            invalid.innerHTML = 'invalid link';
        }
    }else{
        warning.style.display = "block";
        invalid.style.display = "none";
    }
}
